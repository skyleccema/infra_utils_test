# app/models/ssr_services.py

from typing import List, Optional
from sqlalchemy.dialects import mysql
from sqlalchemy import Column, Table
from sqlalchemy import ForeignKey, Integer, String, Boolean, Text, Date, DateTime
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy import ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column
from datetime import datetime, date

# mapper_registry = db.registry()

# declarative base class
class Base(DeclarativeBase):
      pass

class InfraDBRackIaas(Base):
    __bind_key__ = 'infradb'
    __tablename__ = 'rack_iaas'

    rack_id:        Mapped[int] = mapped_column(Integer, primary_key=True)
    name:           Mapped[Optional[str]] = mapped_column(String(250))
    ip:             Mapped[Optional[str]] = mapped_column(String(15))
    subnet:         Mapped[Optional[str]] = mapped_column(String(20))
    rack_model:     Mapped[Optional[str]] = mapped_column(String(250))
    slot_number:    Mapped[Optional[int]] = mapped_column(Integer)
    moxa_ip:        Mapped[Optional[str]] = mapped_column(String(15))
    port:           Mapped[Optional[int]] = mapped_column(Integer)
    link_1:         Mapped[Optional[str]] = mapped_column(String(250))
    link_2:         Mapped[Optional[str]] = mapped_column(String(250))

#@dataclass
class InfraDBSlotIaas(Base):
    __bind_key__ = 'infradb'
    __tablename__ = 'slot_iaas'

    slot_id:              Mapped[int] = mapped_column(Integer, primary_key=True)
    rack_id:              Mapped[Optional[int]] = mapped_column("rack_id", Integer, ForeignKey('rack_iaas.rack_id'))
    ethernet_cable:       Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True, default=None)
    serial_cable:         Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True, default=None)
    hdmi_cable:           Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True, default=None)
    sat1:                 Mapped[Optional[str]] = mapped_column(String(250), nullable=True, default=None)
    sat2:                 Mapped[Optional[str]] = mapped_column(String(250), nullable=True, default=None)
    dtt:                  Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True, default=None)
    splitter_audio_video: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True, default=None)
    splitter_video:       Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True, default=None)
    down_scaler:          Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True, default=None)
    status_slot:          Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True, default=None)
    moxa_port:            Mapped[Optional[int]] = mapped_column(Integer, nullable=True, default=None)
    slot_number:          Mapped[Optional[int]] = mapped_column(Integer, nullable=True, default=None)
    note:                 Mapped[str] = mapped_column(Text, nullable=False, default="")
    default_ip:           Mapped[Optional[str]] = mapped_column(String(15), nullable=True, default=None)

    # rack = relationship("InfraDBRackIaas", back_populates="slots")
    # stbs_iaas = relationship("InfraDBStbIaas", back_populates="slot")

    # Definizione relazione molti-a-uno o molti-a-molti con InfraDBRackIaas e InfraDBStbIaas
    # rack: Mapped["InfraDBRackIaas"] = relationship("InfraDBRackIaas", back_populates="slots")
    # stbs_iaas: Mapped[List["InfraDBStbIaas"]] = relationship("InfraDBStbIaas", back_populates="slot")


class InfraDBStbIaas(Base):
    __bind_key__ = 'infradb'
    __tablename__ = 'stb_iaas'
    stb_id:             Mapped[int] = mapped_column(Integer, primary_key=True)
    slot_id:            Mapped[Optional[int]] = mapped_column("slot_id", Integer, ForeignKey('slot_iaas.slot_id'))
    smart_card_id:      Mapped[Optional[int]] = mapped_column("smart_card_id", Integer, ForeignKey('smart_card_iaas.smart_card_id'))
    account_id:         Mapped[Optional[int]] = mapped_column("account_id", Integer, ForeignKey('account_iaas.account_id'))
    country_code:       Mapped[Optional[str]] = mapped_column(String(10), nullable=True, default=None)
    hardware_name:      Mapped[Optional[str]] = mapped_column(String(250), nullable=True, default=None)
    chipId:             Mapped[Optional[str]] = mapped_column(String(250), nullable=True, default=None)
    deviceid:           Mapped[Optional[str]] = mapped_column(String(250), nullable=True, default=None)
    mac_address_br:     Mapped[Optional[str]] = mapped_column(String(17), nullable=True, default=None)
    model_number:       Mapped[Optional[str]] = mapped_column(String(250), nullable=True, default=None)
    receiverId:         Mapped[Optional[str]] = mapped_column(String(250), nullable=True, default=None)
    project:            Mapped[Optional[str]] = mapped_column(String(250), nullable=True, default=None)
    version_number:     Mapped[Optional[str]] = mapped_column(String(250), nullable=True, default=None)
    serial_number:      Mapped[Optional[str]] = mapped_column(String(250), nullable=True, default=None)
    mac_address:        Mapped[Optional[str]] = mapped_column(String(17), nullable=True, default=None)
    ip:                 Mapped[Optional[str]] = mapped_column(String(15), nullable=True, default=None)
    personalized_pin:   Mapped[Optional[str]] = mapped_column(String(4), nullable=True, default=None)
    stb_status:         Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True, default=None)
    auto_rebot:         Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True, default=None)
    note:               Mapped[str] = mapped_column(Text, nullable=False, default="")
    used_for:           Mapped[Optional[str]] = mapped_column(String(250), nullable=True, default=None)
    last_as_status:     Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True, default=None)
    last_as_date:       Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True, default=None)
    last_modified:      Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True, default=None)
    stb_status_info:    Mapped[str] = mapped_column(Text, nullable=False, default="")
    last_as_call:       Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True, default=None)

    # slot = relationship("InfraDBSlotIaas", back_populates="stbs_iaas")
    # smart = relationship("InfraSmartCardIaas", back_populates="stbs_iaas")
    # account = relationship("InfraAccountIaas", back_populates="stbs_iaas")

    # last_check: datetime.datetime.isoformat()
    # slot = db.relationship('InfraDBRack', foreign_keys='InfraDBSlotStatus.slot_id')

    # slot: Mapped["InfraDBSlotIaas"] = relationship("InfraDBSlotIaas", back_populates="stbs_iaas")
    # smart: Mapped["InfraSmartCardIaas"] = relationship("InfraSmartCardIaas", back_populates="stbs_iaas")
    # account: Mapped["InfraAccountIaas"] = relationship("InfraAccountIaas", back_populates="stbs_iaas")

#@dataclass
class InfraSmartCardIaas(Base):
    __bind_key__ = 'infradb'
    __tablename__ = 'smart_card_iaas'

    smart_card_id:  Mapped[int] = mapped_column(Integer, primary_key=True)
    serial_number:  Mapped[Optional[str]] = mapped_column(String(250))
    start_date:     Mapped[Optional[date]] = mapped_column(Date)
    end_date:       Mapped[Optional[date]] = mapped_column(Date)
    owner:          Mapped[Optional[str]] = mapped_column(String(250))
    pin:            Mapped[Optional[str]] = mapped_column(String(4))
    bouquet:        Mapped[Optional[str]] = mapped_column(String(250))
    sub_bouquet:    Mapped[Optional[str]] = mapped_column(String(250))
    name:           Mapped[Optional[str]] = mapped_column(String(250))
    password:       Mapped[Optional[str]] = mapped_column(String(250))
    note:           Mapped[Optional[str]] = mapped_column(Text)

    # stbs_iaas:      Mapped[List["InfraDBStbIaas"]] = relationship("InfraDBStbIaas", back_populates="smart")
    # stbs_iaas = relationship("InfraDBStbIaas", back_populates="smart")


#@dataclass
class InfraAccountIaas(Base):
    __bind_key__ = 'infradb'
    __tablename__ = 'account_iaas'

    account_id:     Mapped[int] = mapped_column(Integer, primary_key=True)
    account:        Mapped[Optional[str]] = mapped_column(String(250))
    customerID:     Mapped[Optional[str]] = mapped_column(String(250))
    macontractID:   Mapped[Optional[str]] = mapped_column(String(250))
    name:           Mapped[Optional[str]] = mapped_column(String(250))
    surname:        Mapped[Optional[str]] = mapped_column(String(250))
    x1accountID:    Mapped[Optional[str]] = mapped_column(String(250))
    bouquet:        Mapped[Optional[str]] = mapped_column(String(250))
    sub_bouquet:    Mapped[Optional[str]] = mapped_column(String(250))
    pin:            Mapped[Optional[str]] = mapped_column(String(4))
    email:          Mapped[Optional[str]] = mapped_column(String(250))
    password:       Mapped[Optional[str]] = mapped_column(String(250))
    start_date:     Mapped[Optional[date]] = mapped_column(Date)
    end_date:       Mapped[Optional[date]] = mapped_column(Date)
    note:           Mapped[Optional[str]] = mapped_column(Text)

    # stbs_iaas:      Mapped[List["InfraDBStbIaas"]] = relationship("InfraDBStbIaas", back_populates="account")
    # stbs_iaas = relationship("InfraDBStbIaas", back_populates="account")


#@dataclass
class InfraDBStbTypeIaas(Base):
    __bind_key__ = 'infradb'
    __tablename__ = 'stb_type_iaas'

    hardware_name:      Mapped[str] = mapped_column(String(250), primary_key=True)
    family:             Mapped[Optional[str]] = mapped_column(String(250))

